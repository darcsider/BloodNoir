/*=====================================================================================
$File: LevelEditor.cpp
$Date: March 20, 2016
$Creator: Jamie Cooper
$Notice: (C) Copyright 2015 by Punch Drunk Squirrel Games LLC. All Rights Reserved.
=====================================================================================*/
#include "LevelEditor.h"

LevelEditor::LevelEditor()
{

}

LevelEditor::~LevelEditor()
{

}

bool LevelEditor::initialize()
{
	return true;
}